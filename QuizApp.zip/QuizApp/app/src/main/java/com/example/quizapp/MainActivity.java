package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView questionText;
    private RadioGroup optionsGroup;
    private RadioButton option1, option2, option3, option4;
    private Button submitButton;

    private final String[] questions = {
            "Who is known as the Father of Computers?",
            "Which planet is known as the Red Planet?",
            "What is the capital of Japan?",
            "Which is the largest ocean on Earth?",
            "Who wrote the national anthem of India?"
    };

    private final String[][] options = {
            {"Charles Babbage", "Alan Turing", "Bill Gates", "Steve Jobs"},
            {"Mars", "Jupiter", "Venus", "Saturn"},
            {"Beijing", "Tokyo", "Seoul", "Bangkok"},
            {"Atlantic Ocean", "Indian Ocean", "Pacific Ocean", "Arctic Ocean"},
            {"Rabindranath Tagore", "Sarojini Naidu", "Bankim Chandra Chattopadhyay", "Subhash Chandra Bose"}
    };

    private final int[] correctAnswers = {0, 0, 1, 2, 0};
    private int currentQuestionIndex = 0;
    private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        questionText = findViewById(R.id.questionText);
        optionsGroup = findViewById(R.id.optionsGroup);
        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);
        option4 = findViewById(R.id.option4);
        submitButton = findViewById(R.id.submitButton);

        loadQuestion();

        submitButton.setOnClickListener(v -> checkAnswer());
    }

    private void loadQuestion() {
        if (currentQuestionIndex < questions.length) {
            questionText.setText(questions[currentQuestionIndex]);
            option1.setText(options[currentQuestionIndex][0]);
            option2.setText(options[currentQuestionIndex][1]);
            option3.setText(options[currentQuestionIndex][2]);
            option4.setText(options[currentQuestionIndex][3]);
            optionsGroup.clearCheck();
        } else {
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            intent.putExtra("score", score);
            intent.putExtra("total", questions.length);
            startActivity(intent);
            finish();
        }
    }

    private void checkAnswer() {
        int selectedId = optionsGroup.getCheckedRadioButtonId();
        if (selectedId == -1) {
            Toast.makeText(this, "Please select an answer!", Toast.LENGTH_SHORT).show();
            return;
        }
        int selectedIndex = optionsGroup.indexOfChild(findViewById(selectedId));
        if (selectedIndex == correctAnswers[currentQuestionIndex]) {
            score++;
        }
        currentQuestionIndex++;
        loadQuestion();
    }
}
